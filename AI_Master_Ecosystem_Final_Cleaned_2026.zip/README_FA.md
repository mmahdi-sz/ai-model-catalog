# پایگاه داده یکپارچه و مهندسی‌شده هوش مصنوعی ۲۰۲۶ (نسخه نهایی و تمیز)

این بسته نتیجه پاک‌سازی، حذف فایل‌های تکراری، استانداردسازی ستون‌های عددی و ادغام تمام ۵۰ فایل اولیه در **۳ فایل CSV جامع و بدون افت داده** است.

---

## فهرست فایل‌های داخل بسته

### ۱. `01_Hardware_And_OS_VRAM.csv` (بانک سخت‌افزار و VRAM واقعی در سیستم‌عامل‌ها — ۶۰۸ ردیف)
شامل مشخصات کامل ۶۰۸ کارت گرافیک، پردازنده‌های اپل سیلیکون و شتاب‌دهنده‌های دیتاسنتر به همراه محاسبه دقیق **VRAM آزاد و قابل استفاده** پس از کسر سربار سیستم‌عامل:
* **منطق شرطی هوشمند:**
  * **پردازنده‌های اپل (M1 تا M5):** تمام ستون‌های ویندوز و لینوکس `N/A` هستند و فقط ۳ ستون مک (`macOS_Default_Wired_Limit_Usable_GB` برای سقف پیش‌فرض ۷۵٪، `macOS_Sysctl_Unlocked_GUI_Usable_GB` برای حالت آنلاک‌شده با دستور `sysctl` و `macOS_Headless_SSH_Usable_GB` برای حالت سرور) مقداردهی شده‌اند.
  * **کارت‌های گرافیک دسکتاپ و لپ‌تاپ (NVIDIA, AMD, Intel):** ستون‌های مک `N/A` هستند و ظرفیت قابل استفاده در **ویندوز ۱۱ معمولی**، **ویندوز ۱۱ سنگین (4K / دو مانیتور)**، **لینوکس KDE Plasma**، **لینوکس GNOME**، **لینوکس Cinnamon**، **لینوکس XFCE** و **لینوکس سرور بدون گرافیک (CLI)** بر اساس درایور هر شرکت محاسبه شده است.
  * **شتاب‌دهنده‌های دیتاسنتر (H100, B200, TPU, Groq و...):** تمام ستون‌های دسکتاپ و مک `N/A` بوده و فقط ستون `Linux_Headless_CLI_Usable_GB` پر شده است.

---

### ۲. `02_Master_AI_Models_Unified.csv` (کاتالوگ تجمیعی تمام مدل‌ها + ضریب کش KV + کوانت‌ها — ۳٬۲۱۱ ردیف)
ترکیب تمام مدل‌های هوش مصنوعی در یک جدول واحد با قابلیت فیلتر و Sort عددی در اکسل:
* **`Model_Type`**: دسته‌بندی مدل شامل `llm`، `tts`، `asr`، `s2s`، `image`، `video` و `music`.
* **`Attention_Code`**: کد معماری توجه (`MLA`، `GQA`، `Hybrid-GDN`، `Hybrid-Mamba`، `SWA`، `CLA`، `MHA` و...).
* **فرمول محاسبه خودکار کش KV با ستون ضریب (`KV_Factor`):**
  * ستون‌های عددی `KV_Factor_GB_Per_1K_FP16`، `KV_Factor_GB_Per_1K_FP8` و `KV_Factor_GB_Per_1K_Q4` ضریب دقیق مصرف گیگابایت به ازای هر ۱٬۰۰۰ توکن (`1K`) را بر اساس **معماری توجه + تعداد پارامترهای مدل** نشان می‌دهند:
    $$\text{Total VRAM (GB)} = \text{Weights\_Size\_GB\_Numeric} + (\text{Context\_K} \times \text{KV\_Factor}) + \text{Activation\_And\_Engine\_Buffer\_GB}$$
* **ستون‌های آماده برای خوانایی انسان:**
  * علاوه بر ضریب فرمول، ستون‌های آماده `KV_Cache_8K_FP16_GB`، `KV_Cache_32K_FP16_GB`، `KV_Cache_32K_FP8_GB` و `KV_Cache_128K_FP8_GB` و جمع نهایی `Ready_32K_Total_VRAM_GB_Numeric` از قبل محاسبه و درج شده‌اند.
* **ستون‌های عددی خالص (`_Numeric`):** برای فیلتر کردن سریع در اکسل (مثلاً `Min_VRAM_GB_Numeric <= 12` یا مرتب‌سازی بر اساس `Primary_Score_Numeric` و `Speed_TPS_Or_RTF_Numeric`).

---

### ۳. `03_KVCache_And_Engines_Reference.csv` (مرجع کامل ۱۲ جدول فنی کش، موتورهای استنتاج و سیستم‌عامل — ۶۳۶ ردیف)
تجمیع ۱۰۰٪ داده‌های تخصصی پوشه‌های ۳، ۴ و ۵ در ۱۲ بخش (`Reference_Section`) بدون حذف حتی یک ردیف:
1. `01_KV_Attention_Architectures` (۴۴ معماری توجه)
2. `02_KV_Quantization_Precision_Benchmarks` (۱۲۴ تست دقت کش و افت کیفیت `PPL Delta` / `Needle Accuracy`)
3. `03_KV_Pruning_And_Paging_Techniques` (۳۷ تکنیک هرس و پیجینگ کش)
4. `04_KV_Runtimes_And_Hardware_Configs` (۶۵ کانفیگ و فلگ اجرایی روی سخت‌افزارها)
5. `05_KV_Hardware_Decision_Matrix` (۱۹۷ سناریوی تصمیم‌گیری VRAM و کانتکست)
6. `06_Inference_Engines_Master_Overview` تا `11_Inference_Engines_Production_Ecosystem` (کالبدشکافی کامل موتورهای `vLLM`، `SGLang`، `llama.cpp`، `ExLlamaV2`، `Ollama`، `LM Studio` و...)
7. `12_OS_VRAM_Idle_Raw_Benchmarks` (۹۶ تست خام مصرف VRAM سیستم‌عامل‌ها)
